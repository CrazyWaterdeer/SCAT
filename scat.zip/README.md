---
All source code, documentation, and workflow for this project were created with the assistance of AI tools, including GitHub Copilot (Claude Opus 4.5) and Anthropic Claude Opus 4.5.
We acknowledge the significant contribution of AI in the development and documentation of this project.
---

# SCAT - Spot Classification and Analysis Tool

**Version 1.0**

A machine learning-based analysis tool for *Drosophila* excreta classification and quantification. SCAT automatically detects, classifies, and analyzes deposits to distinguish ROD (Reproductive Oblong Deposits) from Normal deposits.

📖 **[Detailed Workflow Guide](WORKFLOW.md)** - Step-by-step documentation for each feature

## Features

### Detection & Classification
- **Rule-based Detection**: Two-stage adaptive thresholding (no training required)
- **U-Net Segmentation**: Pixel-level detection with deep learning
- **Random Forest Classifier**: Fast and accurate 7-feature ML model
- **CNN Classifier**: Deep learning with image patches

### Statistical Analysis
- Normality tests (Shapiro-Wilk)
- Group comparisons (t-test, Mann-Whitney U, ANOVA, Kruskal-Wallis)
- Multiple comparison correction (Holm-Bonferroni)
- Effect size calculation (Cohen's d)
- Correlation analysis (Pearson, Spearman)

### Visualizations
- Violin & Box plots with significance annotations
- Mean ± 95% CI plots (publication-ready)
- Effect size forest plots
- PCA plots
- Density heatmaps
- Feature correlation heatmaps
- pH indicator visualization with actual hue colors

### Spatial Analysis
- Nearest Neighbor Distance (NND)
- Clark-Evans clustering index
- Edge vs Center distribution
- Quadrant analysis

### Reporting
- Comprehensive HTML reports
- Excel/CSV export
- Annotated images
- Statistical summaries

## Installation

### Windows (Recommended)

Download `SCAT.exe` from [Releases](https://github.com/CrazyWaterdeer/SCAT/releases) - no Python installation required.

### From Source (All Platforms)

```bash
# Clone repository
git clone https://github.com/CrazyWaterdeer/SCAT.git
cd scat

# Install with uv (recommended)
uv pip install -e .
```

### System Requirements

- **Windows**: Windows 10/11
- **macOS**: macOS 10.15+
- **Linux**: Ubuntu 20.04+ or equivalent

### Optional Dependencies

```bash
# For CNN/U-Net training (GPU recommended)
uv pip install torch torchvision

# For PDF export
uv pip install weasyprint
```

## Quick Start

### Launch GUI

```bash
# Windows executable
SCAT.exe

# From source
uv run python -m scat.cli gui
```

### Basic Workflow

1. **Analysis Tab**: Select image folder → Run analysis → View results
2. **Results Tab**: Browse statistics, visualizations, and export reports
3. **Setup Tab** (optional): Create training data and custom models

### Command Line

```bash
# Full analysis
uv run python -m scat.cli analyze ./images -o results --annotate --visualize --stats

# With custom model
uv run python -m scat.cli analyze ./images --model-type rf --model-path model.pkl

# Labeling GUI
uv run python -m scat.cli label

# Training
uv run python -m scat.cli train --image-dir ./labeled_images --output model.pkl
```

## Output Structure

```
results_YYYYMMDD_HHMMSS/
├── film_summary.csv           # Per-image statistics
├── all_deposits.csv           # All deposit data combined
├── statistics_report.txt      # Statistical analysis
├── report.html                # Comprehensive HTML report
├── deposits/                  # Per-image deposit data (JSON)
├── annotated/                 # Annotated images
└── visualizations/
    ├── dashboard.png
    ├── violin_rod_fraction.png
    ├── mean_ci_rod_fraction.png
    ├── effect_size_forest.png
    ├── pca_plot.png
    ├── correlation_heatmap.png
    └── ...
```

## Classification Criteria

| Type | Circularity | Description |
|------|-------------|-------------|
| Normal | ≥ 0.6 | Round, regular deposits |
| ROD | < 0.6 | Elongated, reproductive deposits |
| Artifact | - | Non-deposit objects (ML only) |

## Python API

```python
from scat import Analyzer, ClassifierConfig

# Configure
config = ClassifierConfig(model_type="rf", model_path="model.pkl")
analyzer = Analyzer(classifier_config=config)

# Analyze single image
result = analyzer.analyze_image("image.tif")
print(f"Normal: {result.n_normal}, ROD: {result.n_rod}")

# Analyze folder
summary = analyzer.analyze_folder("./images")
summary.to_csv("results.csv")
```


## License

MIT License - see [LICENSE](LICENSE) for details.
