# SCAT Workflow Guide

**Version 1.0**

This document provides detailed explanations of each feature in SCAT.

## Overview

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌────────────────┐    ┌──────────────┐
│  Labeling   │ →  │   Training   │ →  │  Detection  │ →  │ Classification │ →  │   Analysis   │
│  (Manual)   │    │  (Learning)  │    │  (Finding)  │    │   (Sorting)    │    │  (Results)   │
└─────────────┘    └──────────────┘    └─────────────┘    └────────────────┘    └──────────────┘
```

**Quick Start Path**: Detection → Classification → Analysis (no training required)

**Custom Model Path**: Labeling → Training → Detection → Classification → Analysis

---

## 1. Labeling

Create training data by manually annotating deposit locations and types.

### How to Access
- Main GUI → Setup Tab → Labeling
- Or: `python -m scat.cli label`

### Keyboard Shortcuts

| Shortcut | Function |
|----------|----------|
| **1** | Label as Normal |
| **2** | Label as ROD |
| **3** | Label as Artifact |
| **A** | Add mode (draw new deposit) |
| **S** | Select mode |
| **D** / Delete | Delete selected |
| **M** | Merge selected deposits |
| **G** | Group selected deposits |
| **U** | Ungroup |
| **N** / **P** | Next / Previous deposit |
| **Ctrl+S** | Save |
| **Ctrl+Z** | Undo |

### Merge vs Group

| Feature | Merge | Group |
|---------|-------|-------|
| **Use case** | Single large deposit detected as multiple | Multiple fragments that are one ROD |
| **Result** | Combined into single contour | Kept as separate contours |
| **Count** | Counts as 1 deposit | Counts as 1 deposit (multiple segments) |

### Output Format

Labels are saved as `image_name.labels.json`:

```json
{
  "image_file": "image.tif",
  "deposits": [
    {
      "id": 0,
      "contour": [[x1, y1], [x2, y2], ...],
      "label": "normal",
      "area": 150.5,
      "circularity": 0.85
    }
  ]
}
```

---

## 2. Training

Build custom models from labeled data.

### How to Access
- Main GUI → Setup Tab → Training
- Or: `python -m scat.cli train --image-dir ./labeled --output model.pkl`

### Model Types

#### U-Net (Detection)

Learns to detect deposit regions at pixel level.

| Property | Value |
|----------|-------|
| Input | 256×256 RGB image |
| Output | Binary segmentation mask |
| Architecture | Encoder-Decoder with skip connections |
| Loss | BCE + Dice Loss |
| Augmentation | 13× (flip, rotate, brightness, contrast, noise) |
| File size | ~50 MB |

**Recommended**: 20-30 labeled images

#### Random Forest (Classification)

Fast feature-based classifier.

| Property | Value |
|----------|-------|
| Features | 7 (hue, saturation, lightness, R, G, B, circularity) |
| Trees | 100 (default) |
| Classes | Normal, ROD, Artifact |
| File size | ~1 MB |

**Recommended**: 200+ labeled deposits

#### CNN (Classification)

Deep learning image patch classifier.

| Property | Value |
|----------|-------|
| Input | 64×64 image patch |
| Architecture | Conv-Pool-Conv-Pool-FC |
| Classes | Normal, ROD, Artifact |
| File size | ~5 MB |

**Recommended**: 500+ labeled deposits

---

## 3. Detection

Find deposit locations in images.

### Rule-based (Default)

Two-stage adaptive thresholding:

1. **Stage 1 (Standard)**: Detects well-defined deposits
   - Adaptive threshold (block=51, C=10)
   - Morphological cleanup
   
2. **Stage 2 (Sensitive)**: Detects dilute deposits
   - Excludes Stage 1 regions
   - Lower threshold (C=5)
   - HSV-based detection

**No training required** - works out of the box.

### U-Net (Learning-based)

Requires trained model (`model_unet.pt`).

| Comparison | Rule-based | U-Net |
|------------|-----------|-------|
| Training required | No | Yes |
| False positives | Higher | Lower |
| Dilute deposits | Two-stage | Learned |
| Speed | Fast | Moderate |

---

## 4. Classification

Assign labels (Normal/ROD/Artifact) to detected deposits.

### Threshold (Default)

Simple circularity-based rule:

```
Circularity < 0.6  →  ROD
Circularity ≥ 0.6  →  Normal
```

- ✅ No training required
- ❌ Cannot detect Artifacts

### Random Forest

Uses 7 color and shape features:

- Mean Hue, Saturation, Lightness
- Mean R, G, B channels
- Circularity

- ✅ Fast and accurate
- ✅ Detects Artifacts
- Requires trained model

### CNN

Analyzes 64×64 image patches directly.

- ✅ Learns complex patterns
- ❌ Requires more training data
- ❌ Slower (GPU recommended)

---

## 5. Analysis

### Running Analysis

1. Select image folder
2. (Optional) Load groups CSV for statistical comparison
3. Configure detection/classification options
4. Click "Run Analysis"

### Groups CSV Format

```csv
filename,group
image1.tif,Control
image2.tif,Control
image3.tif,Treatment
image4.tif,Treatment
```

### Statistical Tests

#### Two Groups
- **Parametric**: Independent t-test
- **Non-parametric**: Mann-Whitney U test

#### Three or More Groups
- **Parametric**: One-way ANOVA + Tukey HSD
- **Non-parametric**: Kruskal-Wallis + Dunn's test

#### Multiple Comparison Correction

When comparing 3+ groups, pairwise p-values are corrected using **Holm-Bonferroni** method to control family-wise error rate.

The HTML report shows:
- **Raw p-value**: Before correction
- **Corrected p-value**: After Holm correction
- 🟢 Green: Significant after correction
- 🟠 Orange: Lost significance after correction

#### Effect Size

**Cohen's d** interpretation:
| d | Interpretation |
|---|----------------|
| < 0.2 | Negligible |
| 0.2 - 0.5 | Small |
| 0.5 - 0.8 | Medium |
| > 0.8 | Large |

---

## 6. Visualizations

### Statistical Plots

| Plot | Description |
|------|-------------|
| **Violin Plot** | Distribution shape with box plot overlay |
| **Box Plot** | Quartiles with outliers |
| **Mean ± CI** | Mean with 95% confidence interval (publication-ready) |
| **Effect Size Forest** | Cohen's d with confidence intervals |

### Feature Plots

| Plot | Description |
|------|-------------|
| **PCA** | 2D projection of feature space |
| **Correlation Heatmap** | Feature relationships |
| **Scatter Matrix** | Pairwise feature plots |

### Spatial Plots

| Plot | Description |
|------|-------------|
| **Density Heatmap** | Deposit concentration |
| **NND Histogram** | Nearest neighbor distances |
| **Quadrant Analysis** | Spatial distribution |

### pH Indicator Visualization

Hue values are displayed using actual colors from the Bromophenol Blue pH indicator spectrum (yellow=acidic → blue=basic).

---

## 7. Output Files

### film_summary.csv

Per-image statistics:

| Column | Description |
|--------|-------------|
| filename | Image file name |
| n_total | Total deposit count |
| n_normal | Normal deposit count |
| n_rod | ROD count |
| n_artifact | Artifact count |
| rod_fraction | ROD / (Normal + ROD) |
| mean_area | Average deposit size |
| mean_hue | Average hue value |
| group | Experimental group (if provided) |

### all_deposits.csv

Individual deposit data:

| Column | Description |
|--------|-------------|
| filename | Source image |
| deposit_id | Unique ID |
| x, y | Center coordinates |
| area_px | Area in pixels |
| circularity | Shape metric (0-1) |
| mean_hue | Average hue (0-180) |
| mean_saturation | Average saturation (0-1) |
| mean_lightness | Average lightness (0-1) |
| label | Classification result |
| confidence | Classifier confidence |

### report.html

Comprehensive HTML report including:
- Summary statistics
- Group comparisons with p-values
- Significant findings
- Key correlations
- Embedded visualizations

---

## 8. Recommended Settings

### Quick Analysis (No Training)

| Stage | Setting |
|-------|---------|
| Detection | Rule-based |
| Classification | Threshold |

Best for: Initial exploration, small datasets

### Accurate Analysis (With Training)

| Stage | Setting | File |
|-------|---------|------|
| Detection | U-Net | model_unet.pt |
| Classification | Random Forest | model_rf.pkl |

Best for: Publication-quality results, large datasets

---

## 9. Troubleshooting

### Detection Issues

**Too many false positives**
- Increase minimum area threshold
- Use U-Net with trained model
- Check image quality

**Missing dilute deposits**
- Enable sensitive detection mode
- Lower threshold values
- Use U-Net trained on similar images

### Classification Issues

**Low accuracy**
- Train with more labeled data
- Ensure balanced classes in training set
- Check if deposits are properly detected first

### Statistical Issues

**Omnibus test significant but pairwise not significant**
- This is expected behavior with Holm correction
- The correction controls false discovery rate
- Raw p-values are also shown for reference

---

## 10. Keyboard Shortcuts Summary

### Labeling

| Key | Action |
|-----|--------|
| 1, 2, 3 | Label Normal, ROD, Artifact |
| A | Add mode |
| S | Select mode |
| D | Delete |
| M | Merge |
| G | Group |
| Ctrl+S | Save |
| Ctrl+Z | Undo |

### Results Viewer

| Key | Action |
|-----|--------|
| 1, 2, 3 | Relabel selected |
| D | Delete selected |
| Ctrl+Z | Undo |
| Esc | Close |
